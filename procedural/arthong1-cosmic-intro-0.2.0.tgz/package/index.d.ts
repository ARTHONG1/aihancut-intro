export interface IntroError { code: string; message: string }
export interface CompletedIntro { status: 'completed'; destination: 'Incheon'; reducedMotion: boolean }
export type IntroResult = CompletedIntro | { status: 'cancelled' } | { status: 'error'; error: IntroError };
export interface IntroOptions {
  /** Directory containing embed/ and assets/. Include the app base path if applicable. */
  baseUrl?: string;
  /** Default: full on an active user click, otherwise auto (system preference). */
  motion?: 'full' | 'reduce' | 'auto';
  /** Request audio; browser autoplay restrictions still apply. Default false. */
  sound?: boolean;
  /** Loading + playback timeout, 5000–120000 ms, default 45000. Pauses in hidden tabs. */
  timeoutMs?: number;
  onComplete?: (result: CompletedIntro) => void;
  onError?: (error: IntroError) => void;
}
export declare const version: string;
export declare function playIntro(options?: IntroOptions): Promise<IntroResult>;
export declare function closeIntro(): void;
