#!/usr/bin/env node
import {initProject,syncProject} from './project.mjs';

try {
  const [command,...args]=process.argv.slice(2);
  if (!command || command==='--help' || command==='help') {
    console.log('cosmic-intro init [--public-dir public] [--base-path /]\ncosmic-intro sync\nRun from your web app project directory.');
  } else {
    if(command!=='init' && command!=='sync') throw new Error('Unknown command. Use init or sync.');
    const options={};
    for(let i=0;i<args.length;i+=2) {
      if(command!=='init' || !['--public-dir','--base-path'].includes(args[i]) || !args[i+1] || args[i+1].startsWith('--'))
        throw new Error('Use init [--public-dir public] [--base-path /].');
      options[args[i]==='--public-dir'?'publicDir':'basePath']=args[i+1];
    }
    const result=command==='init' ? await initProject(process.cwd(),options) : await syncProject(process.cwd());
    console.log(`Cosmic Intro ${result.version} ready.\nPlayer base URL: ${result.baseUrl}`);
    if(command==='init') console.log('npm run build will sync player files. Call playIntro() in the browser.\nFor a non-root app, pass the base URL printed above to playIntro({ baseUrl }).');
  }
} catch(error) {
  console.error('Cosmic Intro:',error.message);
  process.exitCode=1;
}
