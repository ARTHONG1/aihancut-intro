import { readFile, writeFile, mkdir, lstat, readdir, copyFile, realpath } from 'node:fs/promises';
import { resolve, relative, isAbsolute, dirname, sep, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const packageRoot = fileURLToPath(new URL('../', import.meta.url));
const metadata = JSON.parse(await readFile(join(packageRoot,'package.json'),'utf8'));
const configName = '.cosmic-intro.json';
const owner = 'cosmic-intro';
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const json = value => JSON.stringify(value,null,2)+'\n';
async function stat(path) { try { return await lstat(path); } catch(error) { if(error.code==='ENOENT') return null; throw error; } }
async function readJson(path) { return JSON.parse(await readFile(path,'utf8')); }
function contained(root,path) {
  const rel = relative(root,path);
  if (!rel || rel==='..' || rel.startsWith('..'+sep) || isAbsolute(rel)) throw new Error('Directory path must stay inside the project.');
  return path;
}
async function safePath(root,path) {
  contained(root,path);
  let current=root;
  for (const part of relative(root,path).split(sep)) {
    current=join(current,part);
    if ((await stat(current))?.isSymbolicLink()) throw new Error('Symbolic link directory/file paths are not supported.');
  }
  return path;
}
function normalizedConfig(input) {
  const publicDir=input.publicDir ?? 'public';
  let basePath=input.basePath ?? '/';
  if (typeof publicDir!=='string' || !publicDir || isAbsolute(publicDir)) throw new Error('Use a relative public directory path.');
  if (typeof basePath!=='string' || !/^\/(?:[A-Za-z0-9_-]+\/)*[A-Za-z0-9_-]*$/.test(basePath))
    throw new Error('Base path must be a URL path such as / or /school/.');
  if (!basePath.endsWith('/')) basePath+='/';
  return {schema:1,publicDir,basePath};
}
async function filesUnder(root,sub='') {
  const result=[];
  for(const entry of await readdir(join(root,sub),{withFileTypes:true})) {
    const name=sub ? sub+'/'+entry.name : entry.name;
    if(entry.isDirectory()) result.push(...await filesUnder(root,name));
    else if(entry.isFile()) result.push(name);
    else throw new Error('Player contains an unsupported file.');
  }
  return result.sort();
}
async function install(root,config) {
  const publicRoot=await safePath(root,resolve(root,config.publicDir));
  const introRoot=await safePath(root,join(publicRoot,'aihancut-intro'));
  const markerPath=await safePath(root,join(introRoot,'.cosmic-owner.json'));
  if(await stat(introRoot)) {
    if(!(await stat(markerPath)) || (await readJson(markerPath)).owner!==owner)
      throw new Error('Destination conflict: aihancut-intro is not owned by this installer.');
  }
  const relativeRelease=`aihancut-intro/releases/${metadata.version}`;
  const target=await safePath(root,join(publicRoot,relativeRelease));
  const manifestPath=await safePath(root,join(target,'.cosmic-release.json'));
  const source=join(packageRoot,'player');
  const files=await filesUnder(source);
  const hashes={};
  for(const name of files) hashes[name]=hash(await readFile(join(source,name)));
  if(await stat(target)) {
    if(!(await stat(manifestPath))) throw new Error('Release destination conflict: no owned manifest.');
    const previous=await readJson(manifestPath);
    if(previous.owner!==owner || previous.version!==metadata.version || !previous.files) throw new Error('Release manifest conflict.');
    for(const name of await filesUnder(target)) {
      if(name==='.cosmic-release.json') continue;
      await safePath(root,join(target,name));
      if(!previous.files[name] || hash(await readFile(join(target,name)))!==previous.files[name])
        throw new Error(`Locally modified release file conflict: ${name}`);
    }
    for(const name of Object.keys(hashes)) {
      if(previous.files[name] && previous.files[name]!==hashes[name])
        throw new Error('Immutable release conflict: increment the package version before changing player files.');
    }
  }
  await mkdir(target,{recursive:true});
  for(const name of files) {
    const destination=await safePath(root,join(target,name));
    if(!(await stat(destination))) {
      await mkdir(dirname(destination),{recursive:true});
      await copyFile(join(source,name),destination);
    }
  }
  await writeFile(markerPath,json({owner}));
  await writeFile(manifestPath,json({owner,version:metadata.version,files:hashes}));
  return {version:metadata.version,relativeRelease,baseUrl:config.basePath+relativeRelease+'/'};
}
export async function initProject(project,options={}) {
  const root=await realpath(project);
  const configPath=await safePath(root,join(root,configName));
  const existing=(await stat(configPath)) ? await readJson(configPath) : {};
  const config=normalizedConfig({...existing,...options});
  const packagePath=await safePath(root,join(root,'package.json'));
  const pkg=await readJson(packagePath);
  const result=await install(root,config);
  const sync='cosmic-intro sync';
  pkg.scripts ??= {};
  const before=pkg.scripts.prebuild;
  if(before!==sync && !before?.startsWith(sync+' && ')) pkg.scripts.prebuild=before ? sync+' && '+before : sync;
  await writeFile(configPath,json(config));
  await writeFile(packagePath,json(pkg));
  return result;
}
export async function syncProject(project) {
  const root=await realpath(project);
  const configPath=await safePath(root,join(root,configName));
  if(!(await stat(configPath))) throw new Error('Run cosmic-intro init first.');
  const raw=await readJson(configPath);
  if(raw.schema!==1) throw new Error('Unsupported configuration version.');
  return install(root,normalizedConfig(raw));
}
