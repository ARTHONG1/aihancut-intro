'use client';
import { useEffect, useRef } from 'react';
import { playIntro, closeIntro } from './index.js';

/** Plays once per mount. Change its key to replay. Render at most one at a time. */
export function CosmicIntro(options) {
  const latest = useRef(options);
  latest.current = options;
  useEffect(() => {
    let disposed = false;
    let running = false;
    // The first StrictMode setup is disposed before this microtask can start playback.
    queueMicrotask(() => {
      if (disposed) return;
      running = true;
      playIntro({
        ...latest.current,
        onComplete: result => { if (!disposed) latest.current.onComplete?.(result); },
        onError: error => { if (!disposed) latest.current.onError?.(error); },
      }).finally(() => { running = false; });
    });
    return () => { disposed = true; if (running) closeIntro(); };
  }, []);
  return null;
}
