import type { IntroOptions } from './index.js';
/** Plays once per mount; use one instance. Change key to replay. */
export declare function CosmicIntro(props: IntroOptions): null;
