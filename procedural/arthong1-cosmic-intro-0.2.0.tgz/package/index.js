import { createIntroSdk } from './sdk.js';
import { version } from './version.js';

export { version };
let sdk;

/** Import safely during SSR; call only after the browser document is ready. */
export function playIntro(options = {}) {
  if (typeof window === 'undefined') {
    const error = {code: 'not-browser', message: 'Call playIntro in a browser effect or event handler.'};
    try { options.onError?.(error); } catch (callbackError) { console.error(callbackError); }
    return Promise.resolve({status:'error', error});
  }
  sdk ??= createIntroSdk(window);
  return sdk.play({...options, baseUrl: options.baseUrl ?? `/aihancut-intro/releases/${version}/`});
}

export function closeIntro() { sdk?.close(); }
